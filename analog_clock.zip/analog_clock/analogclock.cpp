#include "analogclock.h"
#include <QVBoxLayout>
#include <QTime>
#include <QFont>
#include <cmath>

AnalogClock::AnalogClock(QWidget *parent) : QWidget(parent), scene(new QGraphicsScene(this)), view(new QGraphicsView(scene, this)),
    timer(new QTimer(this))
{
    view->setRenderHint(QPainter::Antialiasing);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(view);
    setLayout(layout);

    setupClock();
    setupClockHands();
    setupClockNumbers();

    connect(timer, SIGNAL(timeout()), this, SLOT(updateClock()));
    timer->start(1000);
}

void AnalogClock::setupClock() {
    clockFace = new QGraphicsEllipseItem(-50, -50, 100, 100);
    clockFace->setPen(QPen(Qt::black));
    scene->addItem(clockFace);
}

void AnalogClock::setupClockHands() {
    hourHand = new QGraphicsLineItem(0, 0, 0, -20);
    hourHand->setPen(QPen(Qt::black, 3));
    scene->addItem(hourHand);

    minuteHand = new QGraphicsLineItem(0, 0, 0, -30);
    minuteHand->setPen(QPen(Qt::blue, 2));
    scene->addItem(minuteHand);

    secondHand = new QGraphicsLineItem(0, 0, 0, -35);
    secondHand->setPen(QPen(Qt::red, 1));
    scene->addItem(secondHand);
}

void AnalogClock::setupClockNumbers() {
    QFont font("Arial", 8, QFont::Bold);

    for (int i = 1; i <= 12; ++i) {
        qreal angle = i * 29.8;
        qreal x = 45 * sin(qDegreesToRadians(angle));
        qreal y = -43 * cos(qDegreesToRadians(angle));

        textItem = new QGraphicsTextItem(QString::number(i));
        textItem->setPos(x - 7, y - 10);
        textItem->setFont(font);
        scene->addItem(textItem);
    }
}

void AnalogClock::updateClock() {
    QTime time = QTime::currentTime();
    qreal hourAngle = 30 * ((time.hour() % 12) + time.minute() / 60.0);
    qreal minuteAngle = 6 * time.minute();
    qreal secondAngle = 6 * time.second();

    hourHand->setRotation(hourAngle);
    minuteHand->setRotation(minuteAngle);
    secondHand->setRotation(secondAngle);
}

void AnalogClock::resizeEvent(QResizeEvent *event) {
    QWidget::resizeEvent(event);


    view->resetTransform();
    view->scale(width() / 200.0, height() / 200.0);
}
