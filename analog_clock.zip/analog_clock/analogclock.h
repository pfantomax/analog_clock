#ifndef ANALOGCLOCK_H
#define ANALOGCLOCK_H

#include <QWidget>
#include <QGraphicsScene>
#include <QGraphicsEllipseItem>
#include <QGraphicsLineItem>
#include <QGraphicsTextItem>
#include <QGraphicsView>
#include <QTimer>
#include <QResizeEvent>

class AnalogClock : public QWidget
{
    Q_OBJECT
public:
    AnalogClock(QWidget *parent = nullptr);

protected:
    void resizeEvent(QResizeEvent *event) override;

private slots:
    void updateClock();

private:
    QGraphicsScene *scene;
    QGraphicsEllipseItem *clockFace;
    QGraphicsLineItem *hourHand;
    QGraphicsLineItem *minuteHand;
    QGraphicsLineItem *secondHand;
    QGraphicsTextItem *textItem;
    QGraphicsView *view;

    QTimer *timer;

    void setupClock();
    void setupClockHands();
    void setupClockNumbers();
};

#endif // ANALOGCLOCK_H
